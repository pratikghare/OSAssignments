#!/bin/bash



for i in *
do
	if [ -e $i ]
	then
		file=`ls -l $i | awk '{print $5}'`
		if (( $file > 5000 ))
		then
			ls -l $i
		fi 
	fi
done
