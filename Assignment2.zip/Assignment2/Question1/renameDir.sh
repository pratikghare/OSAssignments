#!/bin/bash

for i in *
do
	if [ -d $i ]
	then
		mv $i 'newdir'$i
		echo $i 'renamed to newdir'$i
	fi
done
ls
