#!/bin/bash

for (( i=1; i<=10; i++ ))
do
	if [ -e a$i ]
	then
		echo 'ERROR -- File' a$i 'already Exist!'
	else
		mkdir a$i
	fi
done
