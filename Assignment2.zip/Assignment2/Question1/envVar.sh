#!/bin/bash

echo 'Home : ' $HOME
echo 'Path : ' $PATH
echo 'Shell : ' $SHELL
echo 'History : ' $HISTORY
echo 'Logname : ' $LOGNAME
echo 'Term : ' $TERM
