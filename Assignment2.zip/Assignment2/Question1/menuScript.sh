
#!/bin/bash

while ( true )
do
	echo '1. Find length of String'
	echo '2. Copy a string'
	echo '3. Concat Strings'
	echo '4. Compare two Strings'
	echo '5. Reverse a string'
	read  choice

	case $choice in
	1)
		read -p 'Enter a String : '  str
		echo 'Length of string' $str 'is :' ${#str}
		;;
	2)
		read -p 'Enter a string : ' str
		new=$str
		echo 'New String : ' $new
		;;
	3)
		read -p 'Enter String 1 : ' str1
		read -p 'Enter String 2 : ' str2
		newstr=$str1' '$str2
		echo $newstr
		;;
	4)
		read -p 'Enter String 1 : ' str1
		read -p 'Enter String 2 : ' str2
		if [ $str1 == $str2 ]
		then
			echo 'Strings are equal'
		else
			echo 'Strings are not equal'
		fi
		;;
	5)
		rev=""
		read -p 'Enter a String : ' str
		len=${#str}
		for (( i=len; i>0; i-- ))
		do
			rev1=`expr $str | cut -c $i`
			rev=$rev$rev1
		done
		echo $rev

		;;
	*)
		exit
	;;

	esac
done
